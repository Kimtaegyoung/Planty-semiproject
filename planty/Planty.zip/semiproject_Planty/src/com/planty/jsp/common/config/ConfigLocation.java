package com.planty.jsp.common.config;

public class ConfigLocation {

  public static String mybatisConfigLocation;

}
