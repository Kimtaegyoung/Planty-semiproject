package com.planty.jsp.product.model.dto;

public class PartnerDTO {

}
